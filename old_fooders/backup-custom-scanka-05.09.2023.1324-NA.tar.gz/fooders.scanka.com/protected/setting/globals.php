<?php
define("DB_HOST", "localhost");
define("DB_NAME", "scanka_khateraho");
define("DB_USER", "scanka_khateraho");
define("DB_PASSWORD", "Marketing2023!");
define("fooders", "fooders");
define("eaters", "eaters");
define("mobile", "mobile");
define("admin", "admin");
define("Copyright","IWCN SYSTEMS INC.");
define("SITENAME", "KhateRaho.com"); 
define('Appname', 'KhateRaho.com');
define('show_results_per_page','8');
define('show_results_per_page_review','8');
define('Mandrill_Api_Key','dKd4D3IvdFwIdPhg0P2KWg');
define('kr_fooder_email','fooders@khateraho.com');
define('kr_eater_email','eaters@khateraho.com');
define('kr_support_email','support@khateraho.com');
define('kr_noreply_email','no-reply-accounts@khateraho.com');
define("currency", "&#8377;");//8360 for Rs
define("start_time", "11:00:00");
		define("end_time", "20:00:00");
		$vacations=array("7","2","3","5","6","4","1"); //1-7 for days;
define('smtp_host', 'cloud-1f64f2.managed-vps.net');
define('smtp_username', 'support@cobbleai.com');
define('smtp_password', 'Marketing2023!');
define('smtp_port', '587');
define('FROMNAME', 'KhateRaho');
define('FROMAIL', 'support@cobbleai.com');
define('iv', '7895215780');
define('encryption_key', 'iwcn');
define('cipher', 'AES-256-CBC');
$currency_symbol = "&#8377;";
$order_status_array=array('0'=>'Pending','1'=>'Accept and prepare order','2'=>'Order Ready','3'=>'Delivered and paid','4'=>'Reject');
$order_status_label_array=array('0'=>'<span class="label label-warning middle">Pending</span>',                             
'1'=>'<span class="label label-success label-white middle">Accept and prepare order</span>', 
                             '2'=>'<span class="label label-success label-white middle">Order Ready</span>',                             
							 '3'=>'<span class="label label-danger label-white middle">Delivered and paid</span>',
                             '4'=>'<span class="label label-danger label-white middle">Reject</span>');
/*		define("DB_HOST", "localhost");
		define("DB_NAME", "manoj");
		define("DB_USER", "root");
		define("DB_PASSWORD", "");
		define("fooders", "fooders");
		define("eaters", "eaters"); 
		define("mobile", "mobile");
		define("admin", "starkcrm");
		define("Copyright","IWCN SYSTEMS INC.");
		define("SITENAME", "khateraho.com");	
		define('Appname', 'khateraho.com');
		define('show_results_per_page','8');
		define('show_mobile_comments','5');
		define('show_results_per_page_review','8');		
		define("start_time", "11:00:00");
		define("end_time", "22:00:00");
		$vacations=array("1","2","3","4","5","6","7"); //1-7 for days;
		define("currency", "&#8377;");
	*/	
	define('SEO', 1);
	define('page_type', 0); // 1 for comming soon page and 0 for home page
	$apiKey = urlencode('NmM0ZjRkNDQzMDc4NGI3YTY1NDQzNDZiNGE1YTUzNzE=');
	$sender = urlencode('IWCNKR'); 
		?>


