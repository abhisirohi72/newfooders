

<table style="margin:0;padding: 0;
  background: #FFF;table-layout:fixed;"> 
        <tbody>
            <tr>
                <td>
    <table style="width: 100%;font-size: medium;">
        <tbody>
            <tr>
                
				<th colspan="2"><p  style="text-align:center;padding: 5px 2px;margin: 0; font-size: medium;">Lava Pub & Restaurant gh</p></th>
            </tr>
            <tr>
                <td><p style="padding: 5px 0px;margin: 0;">GST Number : GSTIN1234</p></td>
            </tr>
			<tr>
			<td><p style="padding: 5px 0px;margin: 0;">FSSAI Number : FSSAI-123456</p></td> 
		</tr>
        </tbody>
    </table> 
    
    <table style="width: 100%;font-size: medium;">
        <tbody>
            <tr>
                <td>Date : <span>30, Aug 23</span></td>
                <td style="text-align:right;">Time : <span>06:23 pm</span></td>
            </tr>
            <tr>
                <td>Table #: <span>Counter</span></td>
                <td style="text-align:right;">Order # : <span>103</span></td>
            </tr>
            <tr>
                <th colspan="2"><p  style="text-align:center;padding: 5px 2px;margin: 0; font-size: medium;">Original Receipt</p></th>
            </tr>
        </tbody>
    </table>
    
    <table style="width: 100%;font-size: 12px;">
        <thead>
            <tr>
                <th  style="width: 50%;text-align: left;font-size: 14px;text-transform: uppercase;border-top:1px solid black;border-bottom: 1px solid black;vertical-align: middle;">Item</th>
                <th style=" width: 5%;text-align: center;font-size: 14px;text-transform: uppercase;border-top:1px solid black;border-bottom: 1px solid black;vertical-align: middle;">Qty</th>
                <th style="width: 20%;text-align: center;font-size: 14px;text-transform: uppercase;border-top:1px solid black;border-bottom: 1px solid black;vertical-align: middle;">Rate</th>
                <th style="width: 25%;text-align: right;font-size: 14px;text-transform: uppercase;border-top:1px solid black;border-bottom: 1px solid black;vertical-align: middle;">Amount</th>
            </tr> 
        </thead>
       
        <tbody><tr>
	<td style="font-size: medium;text-align: left;vertical-align: bottom;padding: 3px 0px;width: 60%;min-width: 60%;max-width: 60%;word-break: break-all;">corn pizza</td>
	<td style="font-size: medium;text-align: center;vertical-align: bottom;padding: 3px 0px;">1</td>
	<td style="font-size: medium;text-align: center;vertical-align: bottom;padding: 3px 0px;">&#8377;99</td>
	<td style="font-size: medium;text-align: right;vertical-align: bottom;padding: 3px 0px;">&#8377;99</td> 
</tr><tr>
	<td style="font-size: medium;text-align: left;vertical-align: bottom;padding: 3px 0px;width: 60%;min-width: 60%;max-width: 60%;word-break: break-all;">Cheese pizza</td>
	<td style="font-size: medium;text-align: center;vertical-align: bottom;padding: 3px 0px;">1</td>
	<td style="font-size: medium;text-align: center;vertical-align: bottom;padding: 3px 0px;">&#8377;120</td>
	<td style="font-size: medium;text-align: right;vertical-align: bottom;padding: 3px 0px;">&#8377;120</td> 
</tr><tr> 
                <td colspan="3" style="font-size: medium;text-align: right;vertical-align: bottom;padding: 3px 0px;border-top:1px solid black !important;    padding-right: 12px;">Subtotal</td>
                <td style="font-size: medium;text-align: right;vertical-align: bottom;padding: 3px 0px;border-top:1px solid black !important;">&#8377;219.00</td>
            </tr>
			<tr>
			<td colspan="3" style="font-size: medium;text-align: right;vertical-align: bottom;padding: 3px 0px;    padding-right: 12px;">Discount(&#8377;)</td>
			<td style="text-align: right;font-size: medium;vertical-align: bottom;padding: 3px 0px;">&#8377;0.00</td>
		</tr>
			<tr>
			<td colspan="3" style="font-size: medium;text-align: right;vertical-align: bottom;padding: 3px 0px;    padding-right: 12px;">SCH(5%)</td>
			<td style="text-align: right;font-size: medium;vertical-align: bottom;padding: 3px 0px;">&#8377;10.95</td>
		</tr><tr>
                <td colspan="3" style="font-size: medium;text-align: right;vertical-align: bottom;padding: 3px 0px;    padding-right: 12px;">CGST(6%)</td>
                <td style="text-align: right;font-size: medium;vertical-align: bottom;padding: 3px 0px;">&#8377;13.80</td>
            </tr>
           <tr>
                <td colspan="3" style="font-size: medium;text-align: right;vertical-align: bottom;padding: 3px 0px;    padding-right: 12px;">SGST(6%)</td>
                <td style="text-align: right;font-size: medium;vertical-align: bottom;padding: 3px 0px;">&#8377;13.80</td>
            </tr>
           <tr>
                <th colspan="3" style="text-align: right;font-size: medium;    border-top: 1px dashed black !important;
    border-bottom: 1px dashed black !important;    padding-right: 12px;">Total</th>
                <th  style="text-align: right;font-size: medium;vertical-align: bottom;padding: 3px 0px;border-top: 1px dashed black !important;
    border-bottom: 1px dashed black !important;">&#8377;257.54</th>
            </tr>
        </tbody>
    </table>
    <table style="width: 100%;font-size: 12px;">
        <tbody><tr> 
                <td>
                <p style="text-align:center;padding: 5px 2px;margin: 0;">
            Thank you for your visit!
        </p>
                </td>
            </tr>
        </tbody>
    </table> 

    </td>
            </tr>
        </tbody> 
    </table>
