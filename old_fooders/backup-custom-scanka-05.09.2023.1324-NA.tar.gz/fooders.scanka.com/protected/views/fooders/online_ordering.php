
<div class="page-content">
	<div class="page-header position-relative">
		<h1>Online Ordering</h1>
	</div>
	<!--/.page-header-->
	<div class="row-fluid">
		<div class="span12">
		<div class="row-fluid">
		<div class="span12 text-right">
		<!-- <a href="<?php echo $link->link('add_offer',fooders); ?>" class="btn btn-primary btn-small"> Add Offer</a> -->
		</div></div>
		<div class="space-4"></div>
			<!--PAGE CONTENT BEGINS-->
			<div class="row-fluid">
			<div class="span12 text-center blue"><h1>COMING SOON</h1></div>
			</div>
			
			<!--PAGE CONTENT ENDS-->
		</div>
		<!--/.span-->
	</div>
	<!--/.row-fluid-->
</div>
<!--/.page-content-->

