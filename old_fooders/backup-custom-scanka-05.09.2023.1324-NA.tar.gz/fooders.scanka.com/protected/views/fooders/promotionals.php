	<div class="page-content">
		<div class="page-header position-relative">
			<h1>
				Fooders <small> <i class="icon-double-angle-right"></i> Promotionals Note
				</small>
			</h1>
		</div>
		<!--/.page-header-->

		<div class="row-fluid">
			<div class="span12">
				<!--PAGE CONTENT BEGINS-->



				<div class="row-fluid">
					<table id="sample-table-4"
						class="table table-striped table-bordered table-hover">
						<thead>
							<tr>

								<th class="center"><b>Promotional</b></th>
								<th class="center"><b class="blue">Edit</b></th>
								<th class="center"><b>Delete</b></th>

							</tr>
						</thead>

						<tbody>


							<tr>
								<td class="center"><b class="orange">promotional Note</b></td>
								<td class="center"><button class="btn btn-success btn-mini tooltip-info"
										data-rel="tooltip" data-placement="top" title=""
										data-original-title="Edit" id="bootbox-regular">
										<i class="icon-edit bigger-120"></i>
									</button></td>
								<td class="center">
									 <button class="btn btn-danger btn-mini tooltip-warning"
										data-rel="tooltip" data-placement="top" title=""
										data-original-title="Delete">
										<i class="icon-trash bigger-120"></i>
									</button>
								</td>
							</tr>
						</tbody>
					</table>
				</div>

				<div id="modal-table" class="modal hide fade" tabindex="-1">
					<div class="modal-footer">
						<button class="btn btn-small btn-danger pull-left"
							data-dismiss="modal">
							<i class="icon-remove"></i> Close
						</button>

						<div class="pagination pull-right no-margin">
							<ul>
								<li class="prev disabled"><a href="#"> <i
										class="icon-double-angle-left"></i>
								</a></li>

								<li class="active"><a href="#">1</a></li>

								<li><a href="#">2</a></li>

								<li><a href="#">3</a></li>

								<li class="next"><a href="#"> <i class="icon-double-angle-right"></i>
								</a></li>
							</ul>
						</div>
					</div>
				</div>
				<!--PAGE CONTENT ENDS-->
			</div>
			<!--/.span-->
		</div>
		<!--/.row-fluid-->
	</div>
	<!--/.page-content-->

	