<div class="row text-center top-bottom-padd">
<div class="col-xs-12 col-sm-12 col-lg-12">
<a href="<?php echo $link->link('home',mobile);?>"><img src="<?php echo SITE_URL.'/assets/mobile/img/404.jpg'; ?>" ></a>
</div>
</div>
