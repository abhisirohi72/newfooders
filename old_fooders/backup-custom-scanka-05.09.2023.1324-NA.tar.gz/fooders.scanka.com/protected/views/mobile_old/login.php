<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
   <title>Khateraho</title>
   <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="" alt="Khateraho">
   <meta name="author" content="Khateraho">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.0.0-beta.40/css/uikit.min.css" />
   <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo SITE_URL.'/assets/mobile/css/';?>style.css"/>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.2.3/js/uikit.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.0.0-beta.40/js/uikit-icons.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
 </head> 
<body>
    <style>
      body
      {
        overflow:hidden;
      }  
    </style>
    <!-- ********************************mobile menu********************************* -->
 <div class="mobile_layout">    
    <div class="loginbg">
        
        <div class="uk-inline">
              <img src="<?php echo SITE_URL.'/assets/mobile/img/';?>loginbg.png" class="">
              <div class="uk-position-cover loginpd">
                    <a href="" class="">
                       <img src="<?php echo SITE_URL.'/assets/mobile/img/';?>wlogo.png" class="loginimg">
                    </a>
                  
                  <form class="login_form uk-grid-small uk-margin-medium-top" uk-grid>
                            <div class="uk-width-1-1">
                                 <label>Login with your mobile number / Email</label>
                            </div>
                            <div class="uk-width-3-1">
                                <input class="uk-input" type="text" placeholder="Enter your mobile number / Email">
                            </div>
                            <!--<div class="uk-width-1-1 uk-text-center uk-margin-medium-top">
                                 <label>Or</label>
                            </div>-->
                            <div class="uk-width-1-1 submitpd">
                                <button class="uk-button signup" type="submit">Sign up with email <img src="<?php echo SITE_URL.'/assets/mobile/img/';?>signup.png" class=""></button>
                            </div>
                 </form>
              </div>
       </div>
        
        
        
        
        
        
        
        
           
         
        
     </div>
    
 </div>    

