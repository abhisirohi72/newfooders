
      <div class="vh-100 osahan-coming-soon p-4 d-flex justify-content-center align-items-center">
         <div class="osahan-text text-center">
            <div class="osahan-img pb-5">
               <img src="<?php echo SITE_URL.'/assets/mobile/';?>img/not-found.svg" class="img-fluid mx-auto" alt="Responsive image">
            </div>
            <h3 class="text-primary mb-3 font-weight-bold">Page not <b>found</b></h3>
            <p class="lead small mb-0">Oops! Looks like you followed a bad link.</p>
            <a href="<?php echo $link->link('home',mobile); ?>" class="btn btn-outline-primary">Go Back</a>
         </div>
      </div>
