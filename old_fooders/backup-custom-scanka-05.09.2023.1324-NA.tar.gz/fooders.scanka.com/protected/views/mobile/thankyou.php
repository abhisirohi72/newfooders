
<div class="vh-100 osahan-coming-soon p-4 d-flex justify-content-center align-items-center">
<div class="osahan-img text-center">
<img src="<?php echo SITE_URL.'/assets/mobile/';?>img/coming-soon.svg" alt="#" class="img-fluid coming-soon-img">
<div class="osahan-text text-center mt-3">
<h4 class="text-primary font-weight-bold">Your Order Has Been Placed Successfully!!</h4>
<p class="mb-5 h5">Restaurant will get back to you soon.
</p>
   <p class="text-underline mt-4 text-dark"><a >PHONE NUMBER : 8475385059</a></p>
</div>
</div>
</div>
