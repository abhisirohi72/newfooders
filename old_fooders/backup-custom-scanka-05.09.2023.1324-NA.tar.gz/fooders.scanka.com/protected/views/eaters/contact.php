<div class="wrapper">
      
      <div class="row-fluid kr-row-fluid"><div class="span12"></div></div>
      <div class="row-fluid kr-row-fluid"><div class="span12">
      <div class="span3"><h2>&nbsp; Customer Care</h2></div>
      <div class="span9 right"><?php echo $display_contact;?></div>
      </div></div>
      <div class="kr-hr"></div>
      <div class="row-fluid kr-row-fluid"><div class="span12"></div></div>
      <div class="row-fluid kr-row-fluid">
      <div class="span12">
      <div class="span6" style="border-right:2px red solid">
      <div class="row-fluid">
      <div class="span12">
      <div class="span1"></div>
      <div class="span10">     
      <form method="post" action="<?php $_SERVER['PHP_SELF'];?>">
				<input type="hidden" name="contactus_ip" value="<?php echo $password->stringbreak($_SERVER['REMOTE_ADDR']);?>">
				<input type="hidden" name="contactus_check" value="contactus">
					
					<br>
					<div class="row-fluid">
					<div class="span12">
					<input class="krinputboxes" type="text" name="contact_name" value="">
					<label class="krlabel">NAME</label>
					</div>
					</div>
					<br>
					<div class="row-fluid">
					<div class="span12">
					<input class="krinputboxes" type="text" name="contact_email" value="">
					<label class="krlabel">EMAIL</label>
					</div>
					</div>
					<br>
					<div class="row-fluid">
					<div class="span12">
					<input class="krinputboxes" type="text"  name="contact_phone" value="">
					<label class="krlabel">PHONE NUMBER (Optional)</label>
					</div>
					</div>
					<br>
					
					<div class="row-fluid">
					<div class="span12">
					<textarea class="krtextarea" name="contact_message"></textarea>
					<label class="krlabel">MESSAGE</label>
					</div>
					</div>
					<br><br>
					<div class="row-fluid">
					<div class="span12">
					<div class="span5"><button class="button-submit fltlft" type="submit" name="contact_submit"><i class="icon-check"></i> Submit</button></div>
					<div class="span7"></div>
					</div>
					</div>
					<br>
					
					</form>
					</div>
					<div class="span1"></div>
					</div>
 			     </div>
 				</div>
				
				<div class="span6">
				<div class="row-fluid">
				<div class="span12"></div>
				<div class="span12">
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3548.6157710294297!2d78.00636699999998!3d27.199810542419076!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39747747d08e1a03%3A0xafc110cee48166cb!2sKhateRaho.com!5e0!3m2!1sen!2sin!4v1407147569447" width="400" height="300" frameborder="0" style="border:0"></iframe>
				</div>
				</div>
				<br>
				<div class="row-fluid">
				<div class="span12">
				&nbsp; &nbsp; <i class="icon-home" style="font-size:15px;" rel="tooltip" data-placement="top" data-original-title="Khateraho Address"></i>&nbsp;&nbsp; <span style="font-size: 13px;color:#009DFF;">Block No 22 Office 15/16 First Floor , Shoe Market Sanjay Place Agra</span>
				</div>
				</div>
				<div class="row-fluid">
				<div class="span12">
				&nbsp; &nbsp; <i class="icon-envelope" style="font-size:15px;" rel="tooltip" data-placement="top" data-original-title="Khateraho Email"></i>&nbsp;&nbsp; <span style="font-size: 13px;color:#009DFF;">info@khateraho.com</span> 
				</div>
				</div>
				<div class="row-fluid">
				<div class="span12">
				&nbsp; &nbsp; <i class="icon-phone" style="font-size:15px;" rel="tooltip" data-placement="top" data-original-title="Khateraho Phone No."></i>&nbsp;&nbsp;<span style="font-size: 13px;color:#009DFF;">0562 4052090</span> 
				</div>
				</div>
				
				</div>
      
      </div>
  </div>
  
  <div class="row-fluid kr-row-fluid"><div class="span12"></div></div>
  </div>