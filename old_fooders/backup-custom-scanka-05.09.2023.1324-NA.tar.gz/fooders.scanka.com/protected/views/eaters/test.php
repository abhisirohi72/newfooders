<span style="font-size:11.0pt;line-height:107%;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;mso-fareast-font-family:Calibri;so-fareast-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-bidi-theme-font:minor-bidi;mso-ansi-language:EN-US;so-fareast-language:EN-US;mso-bidi-language:AR-SA">Hello Bradley,<br>
I am following up on our last message regarding (5) GBP Review Responses for month 3 and 4 that are waiting for approval.

Please find attached the link's for month 3 &amp; 4 and edit or approve the answers:</span><div> <span style="font-size:11.0pt;line-height:107%;
font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;mso-fareast-font-family:Calibri;mso-fareast-theme-font:minor-latin;so-hansi-theme-font:minor-latin;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-bidi-theme-font:minor-bidi;mso-ansi-language:EN-US;mso-fareast-language:EN-US;so-bidi-language:AR-SA"><br></span> </div><div> <span style="font-size:11.0pt;line-height:107%;font-family:&quot;Calibri&uot;,sans-serif;mso-ascii-theme-font:minor-latin;mso-fareast-font-family:Calibri;mso-fareast-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-font-family:&uot;Times New Roman&quot;;mso-bidi-theme-font:minor-bidi;mso-ansi-language:EN-US;mso-fareast-language:EN-US;mso-bidi-language:AR-SA"> Month 3: https://docs.google.com/document/d/1QtJBr6foSGwdCoDSk_A6Tqgv0xKNVwa_pAO3uQv_nMA/edit
Month 4: https://docs.google.com/document/d/1RH4atIZ5orqGAOHV5OqI1STEES9V592K/edit?rtpof=false&amp;sd=false

Please let us know if you have any questions or concerns.

</span></div><div><span style="line-height: 107%;"><font face="Calibri, sans-serif"><span style="font-size: 14.6667px;">Thank you,
GBP Web 20 Ranker Team.</span><span style="font-size: 11pt;"><br></span></font></span></div>





<span style="font-size:11.0pt;line-height:107%;
font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;mso-fareast-font-family:
Calibri;mso-fareast-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;
mso-bidi-font-family:&quot;Times New Roman&quot;;mso-bidi-theme-font:minor-bidi;
mso-ansi-language:EN-US;mso-fareast-language:EN-US;mso-bidi-language:AR-SA">Hello Bradley,<br>
I am following up on our last message regarding (5) GBP Review Responses for month 3 and 4 that are waiting for approval.

Please find attached the link's for month 3 &amp; 4 and edit or approve the answers:</span><div><span style="font-size:11.0pt;line-height:107%;
font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;mso-fareast-font-family:
Calibri;mso-fareast-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;
mso-bidi-font-family:&quot;Times New Roman&quot;;mso-bidi-theme-font:minor-bidi;
mso-ansi-language:EN-US;mso-fareast-language:EN-US;mso-bidi-language:AR-SA"><br></span></div><div><span style="font-size:11.0pt;line-height:107%;
font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;mso-fareast-font-family:
Calibri;mso-fareast-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;
mso-bidi-font-family:&quot;Times New Roman&quot;;mso-bidi-theme-font:minor-bidi;
mso-ansi-language:EN-US;mso-fareast-language:EN-US;mso-bidi-language:AR-SA">Month 3: https://docs.google.com/document/d/1QtJBr6foSGwdCoDSk_A6Tqgv0xKNVwa_pAO3uQv_nMA/edit
Month 4: https://docs.google.com/document/d/1RH4atIZ5orqGAOHV5OqI1STEES9V592K/edit?rtpof=false&amp;sd=false

Please let us know if you have any questions or concerns.

</span></div><div><span style="line-height: 107%;"><font face="Calibri, sans-serif"><span style="font-size: 14.6667px;">Thank you,
GBP Web 20 Ranker Team.</span><span style="font-size: 11pt;"><br></span></font></span></div>