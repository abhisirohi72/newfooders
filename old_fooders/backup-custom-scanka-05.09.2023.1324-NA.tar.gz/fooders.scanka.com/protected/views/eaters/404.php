       
        <div class="wrapper" >
       
        	<div class="row-fluid kr-row-fluid">
            <div class="span12 space-404">
            <div class="span6">
            <div class="row-fluid">
            <div class="span12">
            <img src="<?php echo SITE_URL.'/assets/eaters/img/404-2.jpg';?>" >
            </div>
            </div>
            </div>
            <div class="span6">
            <div class="row-fluid">
                <div class="span12">
                <div class="span2"></div>
                <div class="span10">
                <img src="<?php echo SITE_URL.'/assets/eaters/img/404-1.jpg';?>" >
                </div>
                </div>
                </div>
             <div class="row-fluid">
                <div class="span12">
               <h1 class="heading-404">CAN'T YOU SEE I'M EATING</h1>
                </div>
                </div>
                <br>
                <div class="row-fluid">
                <div class="span12">
               <h2 >I know your appetite is killing you , <br>but i don't want to share my food ...<br>so move on !</h2>
                </div>
                </div>
                <br>
                <div class="row-fluid">
                <div class="span12">
                <div class="span2"></div>
                <div class="span10">
                <a href="<?php echo $link->link('home',eaters);?>"><button type="submit"  name=""><i class="icon-home"></i>  Go Back To Home Page </button></a>
                </div>
                </div>
                </div>
                  </div>
                </div><!-- /col-7 -->
            </div>
       </div><!-- /wrapper -->
       

