 
        
       
        <div class="wrapper" >
        	<div class="row-fluid" style="background-color:#fff; ">
            	<div class="col-9">
             <div class="row-fluid">
                <div class="span12" style="text-align: center;">
                <a href="#"><img src="<?php echo SITE_URL.'/assets/eaters/img/content/investors.png';?>" /></a>
                </div>
                </div>
                <div class="row-fluid" style="padding:2%;">
                <div class="span11">
                <h1>Investor Relations</h1>
                <h3 class="h3-investors">Business Overview:</h3>
                <p class="p-investors"><strong>Khate Raho</strong> is an online food ordering system that enables users to order food items from various restaurants, bakers and confectioners that are available on the khateraho.com website. The system is web based and has mobile web integration it allows users to order their favorite food items from their favorite restaurant, bakers and confectioners and then wait for a confirmation as for food item delivery or takeout.</p>
                
                <h3 class="h3-investors">The Opportunity:</h3>
                <p class="p-investors">We saw an opportunity in Agra&#146;s restaurants, bakers and confectioners they usually have low profiles in terms of internet,
public reach is limited, customer hesitation on prices and name fame is variable.
The solution is an online food ordering system that will deal with all the above mentioned barriers and in turn provides various
options for customers along with order accuracy, increase service efficiency by offering an alternative to physical queues and
variety of food items at a single place ensuring time saving and customer satisfaction.</p>
                
                <h3 class="h3-investors">The Market:</h3>
                <p class="p-investors">Our target is more than 150 restaurants, bakers and confectioners in the Agra business district along with suburban areas. The urban working populace is also our target market and this means over a million people in businesses, institutions, other work zones and tourism industry. Due to fame of TAJMAHAL, Foreigners visiting Agra will also be our target along with aata enabled mobile phone users.</p>
                
                <h3 class="h3-investors">Strategy:</h3>
                <p class="p-investors">By allowing restaurants to join our site free of charge we hope to capture over 100 restaurants within the first fiscal year, we
shall position our system by negotiating with restaurants to offer discounts on online orders and coupons to regular customers.
Our marketing strategy is to advertise to consumers through subscribing restaurants, delivery outfits and social sites we will
carry out promotions to institutions and companies.</p>
                
                <h3 class="h3-investors">Competition:</h3>
                <p class="p-investors">There are no competitors in Agra related to this kind of service, But globally there are many like justeat.in ,zomato.com etc.
Our system already has a login control panel which makes restaurant,baker and confectioner owners to easily upload there
menus, food items , about us page, contact info page , reviews and comments section , coupons and various other features, thus leaving all other food ordering sites in india a way behind. After covering agra we plan to move in other regions.</p>
                
                <h3 class="h3-investors">Revenue plan:</h3>
                <p class="p-investors">We will charge as per subscription on paid features per each per restaurant as our main source of revenue. In future once we have attained volumes we shall consider advertisements on our platform as a source of revenue.</p>
                
                <h3 class="h3-investors">Team:</h3>
                <p class="p-investors">Our Top Level Team comprises of the chief executive, managing director ,the technical lead and operations manager. We intend to hire a marketing staff by the 2nd quarter.</p>
              
                <p><b>So What are you waiting for, <a href="<?php echo $link->link('contact',eaters);?>">Contact Us</a>.</b></p>
                </div>
                
                </div>
                                         
                </div><!-- /col-7 -->
                
            </div>
        </div><!-- /wrapper -->
   
