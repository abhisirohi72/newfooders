 
        
       
        <div class="wrapper" >
        	<div class="row-fluid" style="background-color:#fff; ">
            	<div class="col-7">
                <div class="row-fluid">
                <div class="span12" >
                <a href="#"><img src="<?php echo SITE_URL.'/assets/eaters/img/content/growbusiness-header.png';?>" /></a>
                </div>
                </div>
                <div class="row-fluid" style="padding:2%;">
                <div class="span11">
                <h1 class="h1-red">Grow Your Business !</h1>
                <p class="content-p"><strong>Khate Raho</strong> offers state of the art online  ordering solutions along with options for pick up, delivery, specials,  discounts, repeat orders, customer order history and much more. At&nbsp;<strong>no  cost </strong>&nbsp;to you, your  restaurant&#146;s/bakery&#146;s online ordering feature will be available on the Khate  Raho portal and can be integrated directly into your own website with zero  downtime and no additional programming.</p>
                <p class="content-p">Customize your online menu to include deals, lunch and dinner specials, and other custom options. Your menu items will be showcased by pictures and also graphic indicators for spice level, healthy items, and other competitive distinctions.</p>
                <p class="content-p"><strong>Khate Raho</strong>&#146;s built-in marketing capabilities allow you to feature upcoming events, offer discounts on certain days of the week, and even participate in the <strong>Khate Raho</strong> online rewards program that will benefit frequent customers for their online purchases.</p>
                <p class="content-p">Customize your online orders to meet your needs. You can specify order preparation time, order volume, minimum order amounts by area, service charge and other specifications. You can control your order volumes to match the demand and scale at a pace you are comfortable with.</p>
                <p class="content-p"><strong>Khate Raho</strong> does not leave order fulfilment to chance. We can notify via email, and phone. Utilizing this three pronged method you can be certain every order placed online is received just the same as the orders you currently receive over the phone or in person. You can easily define the delivery area, delivery charge, and minimum order amount. In addition, we can send messages directly to your delivery people about pending deliveries and upcoming orders and help manage your delivery logistics.</p>
                <p class="content-p"><strong>Khate Raho</strong> offers the customer convenient and easy methods to pay for their online orders. <strong>Khate Raho</strong> will reimburse you weekly for orders that are placed through the <strong>Khate Raho</strong> portal virtually eliminating any monthly receivable delays. While <strong>Khate Raho</strong> will email you a weekly activity report, you can access your account online at any time. The reports will be organized by monthly activity, individual order detail and most importantly customer history and details. These analytics and trend reports will provide you with the necessary information to evaluate the success of your online business channel.</p>
                <p class="content-p"><strong>Khate Raho</strong> only receives payment after you receive payment from the customer. There is no upfront cost, no monthly fee, and our online ordering solution comes with a full 100% risk free guarantee. If you choose to discontinue service with <strong>Khate Raho</strong> you may do so at any time and for any reason.</p>
                <p class="content-p"><b>Hey Fooder/ Restaurant/ Baker/ Confectioner, if you would like to Pre-register on KhateRaho (which is free and will always be), So Just <a href="<?php echo $link->link('contact',eaters);?>">Contact Us</a></b></p>
                </div>
                </div>
                </div><!-- /col-7 -->
                <div class="col-2">
                	<div style="text-align:center">
                    	<a href="#"><img src="<?php echo SITE_URL.'/assets/eaters/img/content/growbusiness.png';?>" width="220" /></a>
                    </div><!-- /col-2 -->
                   
                </div>
            </div>
        </div><!-- /wrapper -->
   
